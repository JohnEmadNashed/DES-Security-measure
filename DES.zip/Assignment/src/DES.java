import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

public class DES {
	String plainMessage;
	String key;

	// Tables
	static int[] ipMessage = { 58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36,
		28, 20, 12, 4, 62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40, 32,
		24, 16, 8, 57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19,
		11, 3, 61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7 };

	static int[] ipKey = { 57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26,
		18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36, 63, 55,
		47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45,
		37, 29, 21, 13, 5, 28, 20, 12, 4 };

	static int[] finalPermutation = { 40, 8, 48, 16, 56, 24, 64, 32, 39, 7, 47,
		15, 55, 23, 63, 31, 38, 6, 46, 14, 54, 22, 62, 30, 37, 5, 45, 13,
		53, 21, 61, 29, 36, 4, 44, 12, 52, 20, 60, 28, 35, 3, 43, 11, 51,
		19, 59, 27, 34, 2, 42, 10, 50, 18, 58, 26, 33, 1, 41, 9, 49, 17,
		57, 25 };

	static int[] keyChoice = { 14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23,
		19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2, 41, 52, 31, 37, 47, 55, 30,
		40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32 };

	static int[] expansionTable = { 32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9,
		10, 11, 12, 13, 12, 13, 14, 15, 16, 17, 16, 17, 18, 19, 20, 21, 20,
		21, 22, 23, 24, 25, 24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1 };

	static int[][] S1 = {
		{ 14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7 },
		{ 0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8 },
		{ 4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0 },
		{ 15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13 } };
	static int[] [] S2 = {
		{ 15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10 },
		{ 3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5 },
		{ 0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15 },
		{ 13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9 } };

	static int[][] S3 = {
		{ 10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8 },
		{ 13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1 },
		{ 13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7 },
		{ 1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12 } };

	static int[][] S4 = {
		{ 7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15 },
		{ 13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9 },
		{ 10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4 },
		{ 3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14 } };

	static int[][] S5 = {
		{ 2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9 },
		{ 14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6 },
		{ 4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14 },
		{ 11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3 } };

	static int[][] S6 = {
		{ 12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11 },
		{ 10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8 },
		{ 9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6 },
		{ 4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13 } };

	static int[][] S7 = {
		{ 4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1 },
		{ 13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6 },
		{ 1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2 },
		{ 6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12 } };

	static int[][] S8 = {
		{ 13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7 },
		{ 1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2 },
		{ 7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8 },
		{ 2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11 } };

	static int[] permutationTableP = { 16, 7, 20, 21, 29, 12, 28, 17, 1, 15,
		23, 26, 5, 18, 31, 10, 2, 8, 24, 14, 32, 27, 3, 9, 19, 13, 30, 6,
		22, 11, 4, 25 };

	static int[] rotateLeft = { 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1 };

	// Variables
	static String[] bitsPermuted = new String[64];
	static String[] keyPermuted = new String[56];
	static String[] removedParity = new String[56];
	static String C;
	static String D;
	static String[] CInArray = new String[28];
	static String[] DInArray = new String[28];
	static String CInString;
	static String DInString;
	static String concatStrings;
	static String[] keyChoicePermuted = new String[48];
	static String[] finalKey = new String[16];
	static String permutedMessageString;
	static String keyMessageString;
	static String L;
	static String R;
	static String[] expanded = new String[48];
	static String expandedOutput;
	static String afterXOR;
	static String S_1;
	static String S_2;
	static String S_3;
	static String S_4;
	static String S_5;
	static String S_6;
	static String S_7;
	static String S_8;
	static int R_1;
	static int R_2;
	static int R_3;
	static int R_4;
	static int R_5;
	static int R_6;
	static int R_7;
	static int R_8;
	static int C_1;
	static int C_2;
	static int C_3;
	static int C_4;
	static int C_5;
	static int C_6;
	static int C_7;
	static int C_8;
	static String afterS1;
	static String afterS2;
	static String afterS3;
	static String afterS4;
	static String afterS5;
	static String afterS6;
	static String afterS7;
	static String afterS8;
	static String lolololooooooy;
	static String [] pPermuted = new String[32];
	static String [] rDash = new String[32];
	static String Rnew;
	static String Lnew;
	static String [] output = new String [16];
	static String [] finalPermuted = new String[64];
	static String [] finalPermutedECB = new String[64];
	static String [] chunks;
	static String [] savePermutation;
	static String [] calling;
	static String resultECB = "";
	static String resultCBC = "";
	static String[] callingFinal;
	static String keyy = "graduate";
	static Boolean flag = false;

	// Convert the String into binary bits
	public static String stringToBits(String s) {
		byte[] bytes = s.getBytes();
		StringBuilder binary = new StringBuilder();
		for (byte b : bytes) {
			int val = b;
			for (int i = 0; i < 8; i++) {
				binary.append((val & 128) == 0 ? 0 : 1);
				val <<= 1;
			}
			binary.append("");
		}
		return binary.toString();
	}

	// Put the Strings into an array of 64 bits
	public static String[] bitsInArray64(String s) {
		String[] result = new String[64];
		for (int i = 0; i <= s.length() - 1; i++) {
			result[i] = s.charAt(i) + "";
		}
		return result;
	}

	// Put the Strings into an array of 28 bits
	public static String[] bitsInArray28(String s) {
		String[] result = new String[28];
		for (int i = 0; i <= s.length() - 1; i++) {
			result[i] = s.charAt(i) + "";
		}
		return result;
	}

	// Put the Strings into an array of 56 bits
	public static String[] bitsInArray56(String s) {
		String[] result = new String[56];
		for (int i = 0; i <= s.length() - 1; i++) {
			result[i] = s.charAt(i) + "";
		}
		return result;
	}

	// Put the Strings into an array of 32 bits
	public static String[] bitsInArray32(String s) {
		String[] result = new String[32];
		for (int i = 0; i <= s.length() - 1; i++) {
			result[i] = s.charAt(i) + "";
		}
		return result;
	}

	// Put the Strings into an array of 48 bits
	public static String[] bitsInArray48(String s) {
		String[] result = new String[48];
		for (int i = 0; i <= s.length() - 1; i++) {
			result[i] = s.charAt(i) + "";
		}
		return result;
	}

	// Convert an array to String
	public static String ArrayToString(String[] arr) {
		String s = "";
		for (int i = 0; i < arr.length; i++) {
			s = s + arr[i];
		}
		return s;
	}

	// Permutation of the plain message
	public static String[] permutationTable(String plainMessage) throws FileNotFoundException {
		int length = plainMessage.length();
		String bits = null;
		if(length < 8){
			bits = padding(plainMessage);
			//System.out.println("ana a2al men 8");
			String[] bitsInArray = bitsInArray64(bits);
			for (int i = 0; i <= (ipMessage.length) - 1; i++) {
				bitsPermuted[i] = bitsInArray[ipMessage[i] - 1];
			}
		}
		else if (length == 8){
			//System.out.println("ana 8");
			bits = stringToBits(plainMessage);
			String[] bitsInArray = bitsInArray64(bits);
			for (int i = 0; i <= (ipMessage.length) - 1; i++) {
				bitsPermuted[i] = bitsInArray[ipMessage[i] - 1];
			}
		}
		else if (length > 8){
			//System.out.println("ana akbar men 8");
			//CBC or EBC
			flag = true;
			CBC(plainMessage);
			ECB(plainMessage);
		}
		return bitsPermuted;
	}

	// Permutation of xored result in case of CBC
	public static String[] permutationTableCBC(String key) {
		String[] bitsInArray = bitsInArray64(key);
		for (int i = 0; i <= (ipMessage.length) - 1; i++) {
			bitsPermuted[i] = bitsInArray[ipMessage[i] - 1];
		}
		return bitsPermuted;
	}

	// Permutation of the key
	public static String[] permutationKey(String key) {
		String bits = stringToBits(key);
		String[] keyInArray = bitsInArray64(bits);
		for (int i = 0; i <= (ipKey.length) - 1; i++) {
			keyPermuted[i] = keyInArray[ipKey[i] - 1];
		}
		return keyPermuted;
	}

	// Permutation of the keyChoice
	public static String[] keyChoicePermutation(String key) {
		String[] keyInArray = bitsInArray56(key);
		for (int i = 0; i <= (keyChoice.length) - 1; i++) {
			keyChoicePermuted[i] = keyInArray[keyChoice[i] - 1];
		}
		return keyChoicePermuted;
	}

	// Permutation of the expansion
	public static String[] expansion(String key) {
		String[] keyInArray = bitsInArray32(key);
		for (int i = 0; i <= (expansionTable.length) - 1; i++) {
			expanded[i] = keyInArray[expansionTable[i] - 1];
		}
		return expanded;
	}

	// Permutation of the Table P
	public static String[] permutationP(String key) {
		String[] keyInArray = bitsInArray56(key);
		for (int i = 0; i <= (permutationTableP.length) - 1; i++) {
			pPermuted[i] = keyInArray[permutationTableP[i] - 1];
		}
		return pPermuted;
	}

	// Generation of keys block
	public static String[] keyGeneration(String s) {
		// Split the 56 bits into 2 arrays 28 bits each
		C = s.substring(0, (s.length()) / 2);
		D = s.substring(((s.length()) / 2), (s.length()));
		CInArray = bitsInArray28(C);
		DInArray = bitsInArray28(D);

		for (int k = 0; k < rotateLeft.length; k++) {
			int bitsToRotate = rotateLeft[k];
			System.out.print("");

			// rotate left C
			for (int i = 0; i < bitsToRotate; i++) {
				for (int j = 0; j < (CInArray.length) - 1; j++) {

					String temp1 = CInArray[j];
					CInArray[j] = CInArray[j + 1];
					CInArray[j + 1] = temp1;
				}
			}

			// rotate left D
			for (int i = 0; i < bitsToRotate; i++) {
				for (int j = 0; j < DInArray.length - 1; j++) {
					String temp2 = DInArray[j];
					DInArray[j] = DInArray[j + 1];
					DInArray[j + 1] = temp2;
				}
			}

			// combine C & D
			CInString = ArrayToString(CInArray);
			DInString = ArrayToString(DInArray);
			concatStrings = CInString.concat(DInString);

			// Choice of bits for the key (Permutation)
			finalKey[k] = ArrayToString(keyChoicePermutation(concatStrings));
		}
		return finalKey;
	}

	// Generation of output encrypted from fround method
	public static String fRound(String[] permutedMessage) {
		output[0] = ArrayToString(permutedMessage);

		for (int i = 0; i < finalKey.length; i++) {
			if (i == 0) {
				permutedMessage[0] = (output[0]);
			} else {
				permutedMessage[i] = (output[i-1]);

			}
			permutedMessageString = permutedMessage[i];
			L = permutedMessageString.substring(0,
					(permutedMessageString.length()) / 2);

			R = permutedMessageString.substring(
					((permutedMessageString.length()) / 2),
					(permutedMessageString.length()));
			expandedOutput = ArrayToString(expansion(R));
			afterXOR = XORing(expandedOutput, finalKey[i]);
			S_1 = afterXOR.substring(0, 6);
			S_2 = afterXOR.substring(6, 12);
			S_3 = afterXOR.substring(12, 18);
			S_4 = afterXOR.substring(18, 24);
			S_5 = afterXOR.substring(24, 30);
			S_6 = afterXOR.substring(30, 36);
			S_7 = afterXOR.substring(36, 42);
			S_8 = afterXOR.substring(42, 48);
			R_1 = Integer.parseInt(S_1.charAt(0) + "" + S_1.charAt(5), 2);
			R_2 = Integer.parseInt(S_2.charAt(0) + "" + S_2.charAt(5), 2);
			R_3 = Integer.parseInt(S_3.charAt(0) + "" + S_3.charAt(5), 2);
			R_4 = Integer.parseInt(S_4.charAt(0) + "" + S_4.charAt(5), 2);
			R_5 = Integer.parseInt(S_5.charAt(0) + "" + S_5.charAt(5), 2);
			R_6 = Integer.parseInt(S_6.charAt(0) + "" + S_6.charAt(5), 2);
			R_7 = Integer.parseInt(S_7.charAt(0) + "" + S_7.charAt(5), 2);
			R_8 = Integer.parseInt(S_8.charAt(0) + "" + S_8.charAt(5), 2);
			C_1 = Integer.parseInt(S_1.substring(1, 5), 2);
			C_2 = Integer.parseInt(S_2.substring(1, 5), 2);
			C_3 = Integer.parseInt(S_3.substring(1, 5), 2);
			C_4 = Integer.parseInt(S_4.substring(1, 5), 2);
			C_5 = Integer.parseInt(S_5.substring(1, 5), 2);
			C_6 = Integer.parseInt(S_6.substring(1, 5), 2);
			C_7 = Integer.parseInt(S_7.substring(1, 5), 2);
			C_8 = Integer.parseInt(S_8.substring(1, 5), 2);

			afterS1 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S1[R_1][C_1]))));
			afterS2 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S2[R_2][C_2]))));
			afterS3 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S3[R_3][C_3]))));
			afterS4 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S4[R_4][C_4]))));
			afterS5 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S5[R_5][C_5]))));
			afterS6 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S6[R_6][C_6]))));
			afterS7 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S7[R_7][C_7]))));
			afterS8 = String.format("%04d", Integer.valueOf(String
					.valueOf(Integer.toBinaryString(S8[R_8][C_8]))));
			lolololooooooy = afterS1.concat(afterS2).concat(afterS3)
					.concat(afterS4).concat(afterS5).concat(afterS6)
					.concat(afterS7).concat(afterS8);
			rDash[i] = ArrayToString(permutationP(lolololooooooy));
			Lnew = R;
			Rnew = XORing(L, rDash[i]);
			output[i] = Lnew.concat(Rnew);
		}
		return (output[15]);
	}

	// Swapping
	public static String SwapLeftRight(String s){
		String s_left = s.substring(0, (s.length())/2);
		String s_right = s.substring((s.length())/2,s.length());
		String res = s_right.concat(s_left);
		return res;
	}

	// Permutation of the Final Table IP inverse
	public static String[] finalPermutation(String key) {
		String[] beforeLastPermutation = bitsInArray64(SwapLeftRight(output[(output.length)-1]));
		for (int i = 0; i <= (finalPermutation.length) - 1; i++) {
			finalPermuted[i] = beforeLastPermutation[finalPermutation[i] - 1];
		}

		if(flag == false){
			System.out.println("output Length: " + finalPermuted.length + " bits" + "\n" + "Encypted output in Binary: "+ ArrayToString(finalPermuted));
			System.out.println("Encypted output in Hex: "+ binaryToHex(ArrayToString(finalPermuted)));
			System.out.println("Encypted output in ASCII: "+ binaryToASCII(ArrayToString(finalPermuted)));
			try{
			    PrintWriter writer = new PrintWriter("/Users/Mr.Wasfy/Documents/10th Semester/Systems & Network Security/Assignments/Assignmnet 1/encypted.txt", "UTF-8");
			    writer.println("output Length: " + finalPermuted.length + " bits" + "\n" + "Encypted output in Binary: "+ ArrayToString(finalPermuted));
			    writer.println("Encypted output in Hex: "+ binaryToHex(ArrayToString(finalPermuted)));
			    writer.println("Encypted output in ASCII: "+ binaryToASCII(ArrayToString(finalPermuted)));
			    writer.close();
			} catch (IOException e) {
			   // do something
			}
		}
		return finalPermuted;
	}

	// Permutation of the Final Table IP inverse in case of ECB and CBC
	public static String[] finalPermutationECB(String m) {
		String[] beforeLastPermutation = bitsInArray64(SwapLeftRight(m));
		for (int i = 0; i <= (finalPermutation.length) - 1; i++) {
			finalPermutedECB[i] = beforeLastPermutation[finalPermutation[i] - 1];
		}
		return finalPermutedECB;
	}

	// CBC
	public static String CBC(String message) throws FileNotFoundException {
		// this is a little tricky.
		chunks = message.split("(?<=\\G.{8})");
		savePermutation = new String[chunks.length];
		calling = new String[chunks.length];
		callingFinal = new String[chunks.length];
		String afterPadding = "";

		Scanner iv = new Scanner(new FileReader("C:/Users/LaLa/Desktop/DES/iv.txt"));
		String IV = ArrayToString(bitsInArray64(iv.next()));
		String [] s2 = permutationKey("graduate");
		finalKey = keyGeneration(ArrayToString(s2));

		String xoredResult = XORing(stringToBits(chunks[0]), stringToBits(IV));
		savePermutation[0] = ArrayToString(permutationTableCBC(xoredResult));
		calling[0] = fRound(bitsInArray64(savePermutation[0]));
		callingFinal[0] = ArrayToString(finalPermutationECB(calling[0]));
		String xoredResult2 = "";
		for (int j = 1; j < chunks.length; j++) {
			if(chunks[j].length() < 8 ){
				afterPadding = padding(chunks[j]);
				xoredResult2 = XORing(afterPadding, callingFinal[j-1]);
			}
			else{
				xoredResult2 = XORing(stringToBits(chunks[j]), callingFinal[j-1]);
			}
			savePermutation[j] = ArrayToString(permutationTableCBC(xoredResult2));
			calling[j] = fRound(bitsInArray64(savePermutation[j]));
			callingFinal[j] = ArrayToString(finalPermutationECB(calling[j]));
		}

		for (int i = 0; i < callingFinal.length; i++) {
			resultCBC = resultCBC.concat(callingFinal[i]);
		}
		System.out.println("ouput_CBC: Length: " + resultCBC.length() + " bits"+ "\n" + "Encypted output in Binary: " + resultCBC);
		System.out.println("Encypted output in Hex: "+ binaryToHex(resultCBC));
		System.out.println("Encypted output in ASCII: "+ binaryToASCII(resultCBC));
		try{
		    PrintWriter writer = new PrintWriter("/Users/Mr.Wasfy/Documents/10th Semester/Systems & Network Security/Assignments/Assignmnet 1/encyptedCBC.txt", "UTF-8");
		    writer.println("ouput_CBC: Length: " + resultCBC.length() + " bits"+ "\n" + "Encypted output in Binary: " + resultCBC);
		    writer.println("Encypted output in Hex: "+ binaryToHex(resultCBC));
		    writer.println("Encypted output in ASCII: "+ binaryToASCII(resultCBC));
		    writer.close();
		} catch (IOException e) {
		   // do something
		}
		return resultCBC;
	}

	// EBC
	public static String ECB(String message) throws FileNotFoundException {
		// this is a little tricky.
		chunks = message.split("(?<=\\G.{8})");
		savePermutation = new String[chunks.length];
		calling = new String[chunks.length];
		callingFinal = new String[chunks.length];
		String[] s2 = permutationKey("graduate");

		finalKey = keyGeneration(ArrayToString(s2));


		for (int i = 0; i < chunks.length; i++) {
			savePermutation[i] = ArrayToString(permutationTable(chunks[i]));	
		}

		for (int i = 0; i < savePermutation.length; i++) {
			calling[i] = fRound(bitsInArray64(savePermutation[i]));
		}
		for (int i = 0; i < calling.length; i++) {
			callingFinal[i] = ArrayToString(finalPermutationECB(calling[i]));

		}
		for (int i = 0; i < callingFinal.length; i++) {
			resultECB = resultECB.concat(callingFinal[i]);
		}
		System.out.println("");
		System.out.println("ouput_ECB: Length: " + resultECB.length() + " bits"+ "\n" + "Encypted output in Binary: " + resultECB);
		System.out.println("Encypted output in Hex: "+ binaryToHex(resultECB));
		System.out.println("Encypted output in ASCII: "+ binaryToASCII(resultECB));
		try{
		    PrintWriter writer = new PrintWriter("/Users/Mr.Wasfy/Documents/10th Semester/Systems & Network Security/Assignments/Assignmnet 1/encyptedEBC.txt", "UTF-8");
		    writer.println("ouput_ECB: Length: " + resultECB.length() + " bits"+ "\n" + "Encypted output in Binary: " + resultECB);
		    writer.println("Encypted output in Hex: "+ binaryToHex(resultECB));
		    writer.println("Encypted output in ASCII: "+ binaryToASCII(resultECB));
		    writer.close();
		} catch (IOException e) {
		   // do something
		}
		return resultECB;
	}

	// XORing of 2 strings
	public static String XORing(String s1, String s2) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < s1.length(); i++)
			sb.append((s1.charAt(i) ^ s2.charAt(i)));

		String result = sb.toString();
		return result;
	}

	// To transpose the array. (This is only for printing)
	public static String transpose(String[] s) {
		String result = "";
		for (int i = 0; i <= s.length - 1; i++) {
			result = result.concat(s[i]);
		}

		return result;
	}

	// Padding
	public static String padding(String s) {
		String bits = stringToBits(s);
		int difference = 64 - bits.length();
		String toBeAdded3ashanKhaterMira = String.format("%0"+difference+"d", Integer.valueOf(String.valueOf(Integer.toBinaryString(difference/8))));		
		return bits.concat(toBeAdded3ashanKhaterMira);
	}

	// Conversions
	public static String asciiToHex(String s) {
		char[] chars = s.toCharArray();
		StringBuffer hex = new StringBuffer();
		for (int i = 0; i < chars.length; i++) {
			hex.append(Integer.toHexString((int) chars[i]));
		}
		return hex.toString();
	}

	public static String binaryToHex(String s){
		chunks = s.split("(?<=\\G.{8})");
		String res = "";
		for (int i = 0; i < chunks.length; i++) {
			int decimal = Integer.parseInt(chunks[i],2);
			String hexStr = Integer.toString(decimal,16);
			res = res.concat(hexStr);
		}
		return res;
	}

	public static String binaryToASCII(String s){
		String s2 = ""; 
		char nextChar;
		for(int i = 0; i <= s.length()-8; i += 9) //this is a little tricky.  we want [0, 7], [9, 16], etc (increment index by 9 if bytes are space-delimited)
		{
			nextChar = (char)Integer.parseInt(s.substring(i, i+8), 2);
			s2 += nextChar;
		}
		return s2;
	}

	public static void main(String[] args) throws FileNotFoundException {

		Scanner message = new Scanner(new FileReader("C:/Users/LaLa/Desktop/DES/message.txt"));
		String[] s1 = permutationTable(message.next());
		//String[] s1 = permutationTable("seniorsss");
		Scanner key = new Scanner(new FileReader("C:/Users/LaLa/Desktop/DES//key.txt"));
		String[] s2 = permutationKey(key.next());
		//String[] s2 = permutationKey("graduate");
		String boo2 = transpose(s2);
		String[] boo4 = keyGeneration(boo2); 
		String boo5 = fRound(s1);
		String boo6 = ArrayToString(finalPermutation(boo5));

	}

	// Malhash lazma
	/*public static String[] removeParity(String key) {
		int j = 0;
		String bits = stringToBits(key);
		String[] bitsInArray = bitsInArray64(bits);
		System.out.println("Before:   " + bits);
		while (j <= 55) {
			for (int i = 0; i <= (bitsInArray.length) - 1; i++) {
				if (!(i == 7 || i == 15 || i == 23 || i == 31 || i == 39
						|| i == 47 || i == 55 || i == 63)) {

					removedParity[j] = bitsInArray[i];
					j++;

				}
			}
		}
		return removedParity;
	}*/
}