
public class lol {
	public static void main(String[] args) {
		String[] bitsPermuted = new String[64];
		System.out.println(bitsPermuted.toString());
	}
	
	
}
